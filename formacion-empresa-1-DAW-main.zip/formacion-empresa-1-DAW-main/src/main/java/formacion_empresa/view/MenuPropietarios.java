/********************************/
/*  Formación Empresa           */
/*  Clase menú propietarios     */
/*  Markel Canales Ramos 1º DAW */
/********************************/

package formacion_empresa.view;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.nio.channels.ClosedByInterruptException;
import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import formacion_empresa.controller.Conexion;
import formacion_empresa.controller.Consultas;
import formacion_empresa.controller.CRUDpropietario;
import formacion_empresa.model.Propietario;

/**
 * @author Markel Canales Ramos
 */
public class MenuPropietarios extends javax.swing.JPanel {

    DefaultTableModel modelo;

    // inicializa el menú
    public MenuPropietarios() {
        initComponents();
        modelo = (DefaultTableModel) TablePropietarios.getModel();
        setVisible(false);

        // cuando se cierre el formulario de inserción se deben habilitar los botones para evitar que se queden desactivados
        jFrameInsertar.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentHidden(ComponentEvent e) {
                habilitarBtns();
            }
        });

        // cuando se cierre el formulario de actualización se deben habilitar los botones para evitar que se queden desactivados
        jFrameModificar.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentHidden(ComponentEvent e) {
                habilitarBtns();
            }
        });
    }
    
    // deshabilita los botones
    public void deshabilitarBtns() {
        btnConsultar.setEnabled(false);
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnExportar.setEnabled(false);
    }
    
    // habilita los botones
    public void habilitarBtns() {
        btnConsultar.setEnabled(true);
        btnInsertar.setEnabled(true);
        btnModificar.setEnabled(true);
        btnEliminar.setEnabled(true);
        btnExportar.setEnabled(true);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jFrameInsertar = new javax.swing.JFrame();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtDNI_ins = new javax.swing.JTextField();
        txtNombre_ins = new javax.swing.JTextField();
        txtEmail_ins = new javax.swing.JTextField();
        txtTelefono_ins = new javax.swing.JTextField();
        btnAceptar_ins = new javax.swing.JButton();
        jFrameModificar = new javax.swing.JFrame();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtID_mod = new javax.swing.JTextField();
        txtDNI_mod = new javax.swing.JTextField();
        txtNombre_mod = new javax.swing.JTextField();
        txtEmail_mod = new javax.swing.JTextField();
        txtTelefono_mod = new javax.swing.JTextField();
        btnAceptar_mod = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablePropietarios = new javax.swing.JTable();
        btnAtras = new javax.swing.JButton();
        btnConsultar = new javax.swing.JButton();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();

        jFrameInsertar.setTitle("Inserción");
        jFrameInsertar.setAlwaysOnTop(true);
        jFrameInsertar.setPreferredSize(new java.awt.Dimension(400, 400));
        jFrameInsertar.setSize(new java.awt.Dimension(400, 400));

        jLabel3.setText("DNI:");

        jLabel2.setText("Nombre:");

        jLabel4.setText("E-mail:");

        jLabel5.setText("Telefono:");

        btnAceptar_ins.setText("Aceptar");
        btnAceptar_ins.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptar_insActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jFrameInsertarLayout = new javax.swing.GroupLayout(jFrameInsertar.getContentPane());
        jFrameInsertar.getContentPane().setLayout(jFrameInsertarLayout);
        jFrameInsertarLayout.setHorizontalGroup(
            jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGap(51, 51, 51)
                .addComponent(txtDNI_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel2)
                .addGap(28, 28, 28)
                .addComponent(txtNombre_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel4)
                .addGap(44, 44, 44)
                .addComponent(txtEmail_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel5)
                .addGap(25, 25, 25)
                .addComponent(txtTelefono_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(btnAceptar_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jFrameInsertarLayout.setVerticalGroup(
            jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txtDNI_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtNombre_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txtEmail_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(txtTelefono_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(btnAceptar_ins))
        );

        jFrameModificar.setTitle("Modificación");
        jFrameModificar.setAlwaysOnTop(true);
        jFrameModificar.setPreferredSize(new java.awt.Dimension(400, 400));

        jLabel6.setText("ID:");

        jLabel7.setText("DNI:");

        jLabel8.setText("Nombre:");

        jLabel9.setText("E-mail:");

        jLabel10.setText("Telefono:");

        btnAceptar_mod.setText("Aceptar");
        btnAceptar_mod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptar_modActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jFrameModificarLayout = new javax.swing.GroupLayout(jFrameModificar.getContentPane());
        jFrameModificar.getContentPane().setLayout(jFrameModificarLayout);
        jFrameModificarLayout.setHorizontalGroup(
            jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel6)
                .addGap(61, 61, 61)
                .addComponent(txtID_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel7)
                .addGap(51, 51, 51)
                .addComponent(txtDNI_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel8)
                .addGap(24, 24, 24)
                .addComponent(txtNombre_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel9)
                .addGap(40, 40, 40)
                .addComponent(txtEmail_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel10)
                .addGap(21, 21, 21)
                .addComponent(txtTelefono_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(btnAceptar_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jFrameModificarLayout.setVerticalGroup(
            jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(txtID_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(txtDNI_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(txtNombre_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(txtEmail_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(txtTelefono_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(btnAceptar_mod))
        );

        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                MenuPropietarios.this.componentShown(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setText("PROPIETARIOS ENCONTRADOS");

        TablePropietarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "DNI", "Nombre", "E-mail", "Telefono"
            }
        ) {
            @SuppressWarnings("rawtypes")
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            @SuppressWarnings("rawtypes")
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TablePropietarios);

        btnAtras.setText("Volver");
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnExportar.setText("Exportar");
        btnExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnAtras)
                .addGap(578, 578, 578)
                .addComponent(btnExportar))
            .addGroup(layout.createSequentialGroup()
                .addGap(270, 270, 270)
                .addComponent(jLabel1))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(btnConsultar)
                .addGap(111, 111, 111)
                .addComponent(btnInsertar)
                .addGap(119, 119, 119)
                .addComponent(btnModificar)
                .addGap(112, 112, 112)
                .addComponent(btnEliminar))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAtras)
                    .addComponent(btnExportar))
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnConsultar)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)))
        );
    }

    // oculta este panel y vuelve al menú principal
    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {
        setVisible(false);
        modelo.setRowCount(0);
    }

    // método que se ejecuta cada vez que se muestra este panel
    // se rellena la tabla utilizando la función consultarTodo() de la clase Consultas
    private void componentShown(java.awt.event.ComponentEvent evt) {
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            ResultSet rs = Consultas.consultarTodo(con, "propietario");

            if (rs == null) {
                throw new SQLException();
            }
            else {
                while (rs.next()) {
                    modelo.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
                }
            TablePropietarios.setModel(modelo);

            con.close();
            }
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al obtener los datos de la tabla Propietario", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    // ordena ejecutar la consulta y la muestra en la tabla
    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();

        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            String id = JOptionPane.showInputDialog(null, "Introduzca el ID del propietario:", "Consultar", JOptionPane.PLAIN_MESSAGE);

            if (id == null) {
                throw new ClosedByInterruptException();
            }

            Propietario p = CRUDpropietario.consultar(con, Integer.parseInt(id));

            if (p == null) {
                throw new SQLException();
            }
            else if (p.getId() == -2) {
                throw new NullPointerException();
            }
            else {
                modelo.setRowCount(0);
                modelo.addRow(new Object[]{p.getId(), p.getDNI(), p.getNombre(), p.getEmail(), p.getTelefono()});
            }

            con.close();
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El valor introducido debe ser un número entero", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al consultar la tabla Propietario", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El ID indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ClosedByInterruptException e) {}
        
        habilitarBtns();
    }

    // muestra el formulario de inserción
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        jFrameInsertar.pack();
        jFrameInsertar.setLocationRelativeTo(null);
        jFrameInsertar.setVisible(true);

    }

    // muestra el formulario de actualización
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        jFrameModificar.pack();
        jFrameModificar.setLocationRelativeTo(null);
        jFrameModificar.setVisible(true);

    }

    // ejecuta el método de borrado de propietario
    // antes de borrar pregunta al usuario si está seguro que quiere realizar esa acción
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            String idStr = JOptionPane.showInputDialog(null, "Introduzca el ID del propietario:", "Eliminar", JOptionPane.PLAIN_MESSAGE);
            if (idStr == null) {
                throw new ClosedByInterruptException();
            }

            int id = Integer.parseInt(idStr);
            int err;

            if (JOptionPane.showConfirmDialog(null, "¿Seguro que quiere eliminar el registro con ID " + id + "?", "Confirmación", JOptionPane.YES_NO_OPTION) == 0) {
                err = CRUDpropietario.eliminar(con, id);
                if (err == -1) {
                    throw new SQLException();
                }
                else if (err == -2) {
                    throw new NullPointerException();
                }
            }

            con.close();
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El valor introducido debe ser un número entero", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar de la tabla Propietario. No se ha realizado ningún cambio", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El ID indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ClosedByInterruptException e) {}
        
        habilitarBtns();
        modelo.setRowCount(0);
        componentShown(null);
    }

    // recibe los datos del formulario y ordena ejecutar la inserción
    private void btnAceptar_insActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String DNI = txtDNI_ins.getText();
            String nombre = txtNombre_ins.getText();
            String email = txtEmail_ins.getText();
            String telefono = txtTelefono_ins.getText();

            if (DNI.isBlank() || nombre.isBlank()) {
                throw new NullPointerException();    
            }

            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            int id_ins = CRUDpropietario.insertar(con, new Propietario(0, DNI, nombre, email, telefono));

            if (id_ins == -1) {
                throw new SQLException();
            }

            JOptionPane.showMessageDialog(null, "Propietario insertado con ID: " + id_ins, "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            con.close();
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Debes introducir al menos DNI y nombre", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar insertar en la tabla Propietario", "Error", JOptionPane.ERROR_MESSAGE);
        }

        jFrameInsertar.setVisible(false);
        habilitarBtns();

        modelo.setRowCount(0);
        componentShown(null);
    }

    // recibe los datos del formulario y ordena ejecutar la actualización
    private void btnAceptar_modActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int id = Integer.parseInt(txtID_mod.getText());
            String DNI = txtDNI_mod.getText();
            String nombre = txtNombre_mod.getText();
            String email = txtEmail_mod.getText();
            String telefono = txtTelefono_mod.getText();

            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            Propietario oldP = CRUDpropietario.consultar(con, id);
            Propietario newP = new Propietario(id, DNI, nombre, email, telefono);

            // si el usuario deja campos en blanco no se actualizarán
            if (newP.getDNI().isBlank()) {
                newP.setDNI(oldP.getDNI());
            }
            if (newP.getNombre().isBlank()) {
                newP.setNombre(oldP.getNombre());
            }
            if (newP.getEmail().isBlank()) {
                newP.setEmail(oldP.getEmail());
            }
            if (newP.getTelefono().isBlank()) {
                newP.setTelefono(oldP.getTelefono());
            }

            int err = CRUDpropietario.actualizar(con, newP);

            if (err == -1) throw new SQLException();
            else if (err == -2) throw new NullPointerException();
            else JOptionPane.showMessageDialog(null, "Los datos han sido modificados correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            con.close();
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID introducido debe ser un número entero", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al actualizar los datos de la tabla Propietario", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El ID indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }

        jFrameModificar.setVisible(false);
        habilitarBtns();

        modelo.setRowCount(0);
        componentShown(null);
    }

    // ordena ejecutar la exportación de la tabla
    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            int err = Consultas.exportar(con, "propietario");

            if (err == 0) {
                JOptionPane.showMessageDialog(null, "Tabla exportada a CSV correctamente");
            }
            else {
                throw new Exception();
            }

            con.close();
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar exportar la tabla Propietario", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    // Variables declaration - do not modify
    private javax.swing.JTable TablePropietarios;
    private javax.swing.JButton btnAceptar_ins;
    private javax.swing.JButton btnAceptar_mod;
    private javax.swing.JButton btnAtras;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JFrame jFrameInsertar;
    private javax.swing.JFrame jFrameModificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtDNI_ins;
    private javax.swing.JTextField txtDNI_mod;
    private javax.swing.JTextField txtEmail_ins;
    private javax.swing.JTextField txtEmail_mod;
    private javax.swing.JTextField txtID_mod;
    private javax.swing.JTextField txtNombre_ins;
    private javax.swing.JTextField txtNombre_mod;
    private javax.swing.JTextField txtTelefono_ins;
    private javax.swing.JTextField txtTelefono_mod;
    // End of variables declaration
}
