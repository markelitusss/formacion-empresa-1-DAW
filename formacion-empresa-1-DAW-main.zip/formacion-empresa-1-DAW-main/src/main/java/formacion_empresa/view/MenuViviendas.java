/********************************/
/*  Formación Empresa           */
/*  Clase menú viviendas        */
/*  Markel Canales Ramos 1º DAW */
/********************************/

package formacion_empresa.view;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.nio.channels.ClosedByInterruptException;
import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import formacion_empresa.controller.Conexion;
import formacion_empresa.controller.Consultas;
import formacion_empresa.controller.CRUDvivienda;
import formacion_empresa.model.Vivienda;

/**
 * @author Markel Canales Ramos
 */
public class MenuViviendas extends javax.swing.JPanel {

    DefaultTableModel modelo;
    int aceptar;
    
    // deshabilita los botones
    public void deshabilitarBtns() {
        btnConsultar.setEnabled(false);
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnExportar.setEnabled(false);
    }
    
    // habilita los botones
    public void habilitarBtns() {
        btnConsultar.setEnabled(true);
        btnInsertar.setEnabled(true);
        btnModificar.setEnabled(true);
        btnEliminar.setEnabled(true);
        btnExportar.setEnabled(true);
    }

    public MenuViviendas() {
        initComponents();
        modelo = (DefaultTableModel) TableViviendas.getModel();
        setVisible(false);

        cmbTipo.addItem("Apartamento");
        cmbTipo.addItem("Ático");
        cmbTipo.addItem("Casa");

        // cuando se cierre el formulario de inserción/actualización se deben habilitar los botones para evitar que se queden desactivados
        jFrame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentHidden(ComponentEvent e) {
                habilitarBtns();
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jFrame = new javax.swing.JFrame();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        btnAceptar = new javax.swing.JButton();
        txtCodigo = new javax.swing.JTextField();
        txtIDpropietario = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtSuperficie = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDescripcion = new javax.swing.JTextArea();
        cmbTipo = new javax.swing.JComboBox<>();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        btnAtras = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableViviendas = new javax.swing.JTable();
        btnConsultar = new javax.swing.JButton();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();

        jFrame.setTitle("Vivienda");
        jFrame.setAlwaysOnTop(true);
        jFrame.setPreferredSize(new java.awt.Dimension(400, 400));
        jFrame.setSize(new java.awt.Dimension(400, 400));

        jLabel2.setText("Código:");

        jLabel3.setText("ID propietario:");

        jLabel4.setText("Dirección:");

        jLabel5.setText("Precio:");

        jLabel6.setText("Superficie (m2):");

        jLabel7.setText("Descripción:");

        jLabel8.setText("Tipo:");

        jLabel9.setText("Acepta mascotas:");

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setSelected(true);
        jRadioButton1.setText("Si");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("No");

        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtDescripcion.setColumns(20);
        txtDescripcion.setRows(5);
        jScrollPane2.setViewportView(txtDescripcion);

        javax.swing.GroupLayout jFrameLayout = new javax.swing.GroupLayout(jFrame.getContentPane());
        jFrame.getContentPane().setLayout(jFrameLayout);
        jFrameLayout.setHorizontalGroup(
            jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel2)
                .addGap(58, 58, 58)
                .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jLabel5)
                .addGap(67, 67, 67)
                .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel3)
                .addGap(19, 19, 19)
                .addComponent(txtIDpropietario, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jLabel6)
                .addGap(17, 17, 17)
                .addComponent(txtSuperficie, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel4)
                .addGap(34, 34, 34)
                .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel7)
                .addGap(21, 21, 21)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel8)
                .addGap(70, 70, 70)
                .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel9)
                .addGap(30, 30, 30)
                .addComponent(jRadioButton1)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton2))
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jFrameLayout.setVerticalGroup(
            jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txtIDpropietario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtSuperficie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrameLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel7))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrameLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel8))
                    .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrameLayout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel9))
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2))
                .addGap(18, 18, 18)
                .addComponent(btnAceptar))
        );

        setPreferredSize(new java.awt.Dimension(800, 600));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                MenuViviendas.this.componentShown(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setText("VIVIENDAS ENCONTRADAS");

        btnAtras.setText("Volver");
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });

        TableViviendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "ID propietario", "Direccion", "Precio", "Superficie", "Descripcion", "Tipo", "Mascota/s"
            }
        ) {
            @SuppressWarnings("rawtypes")
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Double.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            @SuppressWarnings("rawtypes")
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TableViviendas);

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnExportar.setText("Exportar");
        btnExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnAtras)
                .addGap(578, 578, 578)
                .addComponent(btnExportar))
            .addGroup(layout.createSequentialGroup()
                .addGap(270, 270, 270)
                .addComponent(jLabel1))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(btnConsultar)
                .addGap(111, 111, 111)
                .addComponent(btnInsertar)
                .addGap(119, 119, 119)
                .addComponent(btnModificar)
                .addGap(112, 112, 112)
                .addComponent(btnEliminar))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAtras)
                    .addComponent(btnExportar))
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnConsultar)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)))
        );
    }

    // método que se ejecuta cada vez que se muestra este panel
    // se rellena la tabla utilizando la función consultarTodo() de la clase Consultas
    private void componentShown(java.awt.event.ComponentEvent evt) {
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            ResultSet rs = Consultas.consultarTodo(con, "vivienda");
            ResultSet rsTipo = Consultas.consultarCustom(con, "SELECT t.tipo, v.codigo FROM tipo_vivienda t INNER JOIN vivienda v ON t.id = v.tipo ORDER BY v.codigo");

            if (rs == null || rsTipo == null) {
                throw new SQLException();
            }
            else {
                int rowCount = 0;

                while (rs.next() && rsTipo.next()) {
                    modelo.addRow(new Object[]{rs.getString(1), rs.getInt(2), rs.getString(3), rs.getDouble(4), rs.getInt(5), rs.getString(6), rsTipo.getString(1)});
                    Object mascota;
                    if (rs.getBoolean(8)) {
                        mascota = "Si";
                    }
                    else {
                        mascota = "No";
                    }

                    modelo.setValueAt(mascota, rowCount, 7);
                    rowCount++;
                }
            
                TableViviendas.setModel(modelo);
            }

            con.close();
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al obtener los datos de la tabla Vivienda", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // oculta este panel y vuelve al menú principal
    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {
        setVisible(false);
        modelo.setRowCount(0);
    }

    // ordena ejecutar la consulta y la muestra en la tabla
    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            String codigo = JOptionPane.showInputDialog(null, "Introduzca el código de la vivienda:", "Consultar", JOptionPane.PLAIN_MESSAGE);

            if (codigo == null) {
                throw new ClosedByInterruptException();
            }

            Vivienda v = CRUDvivienda.consultar(con, codigo);

            if (v == null) {
                throw new SQLException();
            }
            else if (v.getId_propietario() == -2) {
                throw new NullPointerException();
            }
            else {
                modelo.setRowCount(0);
                modelo.addRow(new Object[]{v.getCodigo(), v.getId_propietario(), v.getDireccion(), v.getPrecio(), v.getSuperficie(), v.getDescripcion(), v.getTipo()});
                
                Object mascota;
                if (v.isAcepta_mascota()) {
                    mascota = "Si";
                }
                else {
                    mascota = "No";
                }

                modelo.setValueAt(mascota, 0, 7);
                con.close();
            }
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al consultar la tabla Vivienda", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El código indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ClosedByInterruptException e) {}

        habilitarBtns();
    }

    // muestra el formulario de inserción/actualización
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        jFrame.pack();
        jFrame.setLocationRelativeTo(null);
        jFrame.setVisible(true);

        aceptar = 1;
    }

    // muestra el formulario de inserción/actualización
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        jFrame.pack();
        jFrame.setLocationRelativeTo(null);
        jFrame.setVisible(true);

        aceptar = 2;
    }

    // ejecuta el método de borrado de vivienda
    // antes de borrar pregunta al usuario si está seguro que quiere realizar esa acción
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            String codigo = JOptionPane.showInputDialog(null, "Introduzca el código de la vivienda:", "Eliminar", JOptionPane.PLAIN_MESSAGE);
            if (codigo == null) {
                throw new ClosedByInterruptException();
            }

            int err;

            if (JOptionPane.showConfirmDialog(null, "¿Seguro que quiere eliminar el registro con codigo " + codigo + "?", "Confirmación", JOptionPane.YES_NO_OPTION) == 0) {
                err = CRUDvivienda.eliminar(con, codigo);
                if (err == -1) {
                    throw new SQLException();
                }
                else if (err == -2) {
                    throw new NullPointerException();
                }
            }

            con.close();
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar de la tabla Vivienda. No se ha realizado ningún cambio", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El código indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ClosedByInterruptException e) {}
        
        habilitarBtns();
        modelo.setRowCount(0);
        componentShown(null);
    }

    // recibe los datos del formulario y ordena ejecutar la inserción/actualización
    // dependiendo del valor de la variable "aceptar" (1 = inserción, 2 = actualización)
    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {
        if (aceptar == 1) {
            try {
                String codigo = txtCodigo.getText();
                int id_propietario = Integer.valueOf(txtIDpropietario.getText());
                String direccion = txtDireccion.getText();
                double precio = Double.parseDouble(txtPrecio.getText());
                int superficie = Integer.parseInt(txtSuperficie.getText());
                String descripcion = txtDescripcion.getText();
                Object tipoObj = cmbTipo.getSelectedItem();
                String tipo = String.valueOf(tipoObj);
                boolean acepta_mascota;
                if (jRadioButton1.isSelected()) {
                    acepta_mascota = true;
                }
                else {
                    acepta_mascota = false;
                }

                if (codigo.isBlank() || txtIDpropietario.getText().isBlank()) {
                    throw new NullPointerException();
                }

                Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
                int err = CRUDvivienda.insertar(con, new Vivienda(codigo, id_propietario, direccion, precio, superficie, descripcion, tipo, acepta_mascota));

                if (err == -1) {
                    throw new SQLException();
                }
                else if (err == -3) {
                    throw new IndexOutOfBoundsException();
                }

                JOptionPane.showMessageDialog(null, "Vivienda insertada correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
                con.close();
            }
            catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Los campos numéricos deben tener valores enteros", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            }
            catch (NullPointerException e) {
                JOptionPane.showMessageDialog(null, "Debes introducir al menos un codigo y un ID de propietario", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            }
            catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar insertar en la tabla Vivienda", "Error", JOptionPane.ERROR_MESSAGE);
            }
            catch (IndexOutOfBoundsException e) {
                JOptionPane.showMessageDialog(null, "El ID del propietario especificado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            }

        }
        else {
            try {
                String codigo = txtCodigo.getText();
                String id_propietario = txtIDpropietario.getText();
                String direccion = txtDireccion.getText();
                String precio = txtPrecio.getText();
                String superficie = txtSuperficie.getText();
                String descripcion = txtDescripcion.getText();
                Object tipoObj = cmbTipo.getSelectedItem();
                String tipo = String.valueOf(tipoObj);
                boolean acepta_mascota;
                if (jRadioButton1.isSelected()) {
                    acepta_mascota = true;
                }
                else {
                    acepta_mascota = false;
                }

                Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
                Vivienda oldV = CRUDvivienda.consultar(con, codigo);
                Vivienda newV = new Vivienda(codigo, 0, direccion, 0, 0, descripcion, tipo, acepta_mascota);

                // si el usuario deja campos en blanco no se actualizarán
                if (id_propietario.isBlank()) {
                    newV.setId_propietario(oldV.getId_propietario());
                }
                else {
                    newV.setId_propietario(Integer.parseInt(id_propietario));
                }

                if (newV.getDireccion().isBlank()) {
                    newV.setDireccion(oldV.getDireccion());
                }
                if (precio.isBlank()) {
                    newV.setPrecio(oldV.getPrecio());
                }
                else {
                    newV.setPrecio(Double.parseDouble(precio));
                }

                if (superficie.isBlank()) {
                    newV.setSuperficie(oldV.getSuperficie());
                }
                else {
                    newV.setSuperficie(Integer.parseInt(superficie));
                }

                if (newV.getDescripcion().isBlank()) {
                    newV.setDescripcion(oldV.getDescripcion());
                }
                if (newV.getTipo().isBlank()) {
                    newV.setTipo(oldV.getTipo());
                }

                int err = CRUDvivienda.actualizar(con, newV);

                if (err == -1) throw new SQLException();
                else if (err == -2) throw new NullPointerException();
                else if (err == -3) throw new IndexOutOfBoundsException();
                else JOptionPane.showMessageDialog(null, "Los datos han sido modificados correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
                con.close();
            }
            catch (NullPointerException e) {
                JOptionPane.showMessageDialog(null, "El código de la vivienda no existe", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            }
            catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar actualizar en la tabla Vivienda", "Error", JOptionPane.ERROR_MESSAGE);
            }
            catch (IndexOutOfBoundsException e) {
                JOptionPane.showMessageDialog(null, "El ID del propietario especificado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        }

        jFrame.setVisible(false);
        habilitarBtns();
            
        modelo.setRowCount(0);
        componentShown(null);
    }

    // ordena ejecutar la exportación de la tabla
    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            int err = Consultas.exportar(con, "vivienda");

            if (err == 0) {
                JOptionPane.showMessageDialog(null, "Tabla exportada a CSV correctamente");
            }
            else {
                throw new Exception();
            }

            con.close();
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar exportar la tabla Vivienda", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    // Variables declaration - do not modify
    private javax.swing.JTable TableViviendas;
    private javax.swing.JButton btnAceptar;
    private javax.swing.JButton btnAtras;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JFrame jFrame;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextArea txtDescripcion;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtIDpropietario;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtSuperficie;
    // End of variables declaration
}
