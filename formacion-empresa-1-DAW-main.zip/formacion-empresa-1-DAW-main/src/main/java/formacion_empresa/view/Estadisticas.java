/********************************/
/*  Formación Empresa           */
/*  Clase menú estadisticas     */
/*  Markel Canales Ramos 1º DAW */
/********************************/

package formacion_empresa.view;

import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import formacion_empresa.controller.Conexion;
import formacion_empresa.controller.Consultas;

/**
 * @author Markel Canales Ramos
 */
public class Estadisticas extends javax.swing.JPanel {

    DefaultTableModel modelo;

    // crea el panel de estadisticas
    public Estadisticas() {
        initComponents();
        modelo = (DefaultTableModel) jTable.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(modelo);
        jTable.setRowSorter(sorter);
        setVisible(false);
    }

    @SuppressWarnings("unchecked")                      
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnAtras = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtMes = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtAnyo = new javax.swing.JTextField();
        btnAplicar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtContratosIniciados = new javax.swing.JTextField();
        txtContratosFinalizados = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtViviendasAlquiler = new javax.swing.JTextField();
        txtPrecioMedio = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable = new javax.swing.JTable();

        setPreferredSize(new java.awt.Dimension(800, 600));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                Estadisticas.this.componentShown(evt);
            }
        });

        txtContratosIniciados.setEditable(false);
        txtContratosFinalizados.setEditable(false);
        txtViviendasAlquiler.setEditable(false);
        txtPrecioMedio.setEditable(false);

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setText("ESTADISTICAS");

        btnAtras.setText("Volver");
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel2.setText("FILTRAR POR FECHA:");

        jLabel3.setText("Mes:");

        jLabel4.setText("Año:");

        btnAplicar.setText("Aplicar filtros");
        btnAplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAplicarActionPerformed(evt);
            }
        });

        jLabel5.setText("Número de contratos iniciados:");

        jLabel6.setText("Número de contratos finalizados:");

        jLabel9.setText("Precio medio alquiler:");

        jLabel10.setText("Viviendas en alquiler:");

        jTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID propietario", "Número viviendas", "Viviendas sin alquiler", "Precio promedio", "Duración promedio"
            }
        ) {
            @SuppressWarnings("rawtypes")
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false, true
            };

            @SuppressWarnings("rawtypes")
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnAtras))
            .addGroup(layout.createSequentialGroup()
                .addGap(330, 330, 330)
                .addComponent(jLabel1))
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel2)
                .addGap(46, 46, 46)
                .addComponent(jLabel3)
                .addGap(20, 20, 20)
                .addComponent(txtMes, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel4)
                .addGap(21, 21, 21)
                .addComponent(txtAnyo, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(100, 100, 100)
                .addComponent(btnAplicar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jLabel5)
                .addGap(28, 28, 28)
                .addComponent(txtContratosIniciados, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(jLabel10)
                .addGap(30, 30, 30)
                .addComponent(txtViviendasAlquiler, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jLabel6)
                .addGap(16, 16, 16)
                .addComponent(txtContratosFinalizados, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(jLabel9)
                .addGap(26, 26, 26)
                .addComponent(txtPrecioMedio, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnAtras)
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(txtMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txtAnyo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAplicar))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtContratosIniciados, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtViviendasAlquiler, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel10))))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(txtContratosFinalizados, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(txtPrecioMedio, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }                    

    // vuelve al menú principal
    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {                                         
        setVisible(false);
        modelo.setRowCount(0);
    }                                        
    
    // cada vez que se muestra este panel ejecuta las consultas sin filtros de fecha
    private void componentShown(java.awt.event.ComponentEvent evt) {                                
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            ResultSet rsContratosIniciados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE fecha_inicio < NOW()");
            rsContratosIniciados.next();
            ResultSet rsContratosFinalizados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE fecha_fin < NOW() AND estado = 3");
            rsContratosFinalizados.next();
            ResultSet rsViviendas = Consultas.consultarCustom(con, "SELECT DISTINCT COUNT(*), ROUND(AVG(precio), 2) FROM contrata WHERE fecha_inicio < NOW() AND estado = 2");
            rsViviendas.next();

            ResultSet rsTabla1 = Consultas.consultarCustom(con, "SELECT id FROM propietario ORDER BY id");
            ResultSet rsTabla2 = Consultas.consultarCustom(con, "SELECT p.id, COUNT(v.codigo) FROM propietario p LEFT JOIN vivienda v ON p.id = v.id_propietario GROUP BY p.id");
            ResultSet rsTabla3 = Consultas.consultarCustom(con, "SELECT p.id, ROUND(AVG(c.precio), 2), AVG(DATEDIFF(c.fecha_fin, c.fecha_inicio)) FROM propietario p INNER JOIN vivienda v ON p.id = v.id_propietario LEFT JOIN contrata c ON c.codigo_vivienda = v.codigo GROUP BY p.id");
            ResultSet rsSinAlquiler = Consultas.consultarCustom(con, "SELECT p.id, COUNT(v.codigo) FROM propietario p INNER JOIN vivienda v ON v.id_propietario = p.id LEFT JOIN contrata c ON c.codigo_vivienda = v.codigo WHERE c.id_inquilino IS NULL GROUP BY p.id");
            
            txtContratosIniciados.setText(String.valueOf(rsContratosIniciados.getInt(1)));
            txtContratosFinalizados.setText(String.valueOf(rsContratosFinalizados.getInt(1)));
            txtViviendasAlquiler.setText(String.valueOf(rsViviendas.getInt(1)));
            txtPrecioMedio.setText(String.valueOf(rsViviendas.getDouble(2)));

            while (rsTabla1.next() && rsTabla2.next() && rsTabla3.next()) {
                modelo.addRow(new Object[]{rsTabla1.getInt(1), rsTabla2.getInt(2), 0, rsTabla3.getDouble(2), rsTabla3.getInt(3)});
            }

            Object id;
            if (rsSinAlquiler.next()) {
                try {
                    for (int i = 0; i < modelo.getRowCount(); i++) {
                        id = rsSinAlquiler.getInt(1);
                        if (modelo.getValueAt(i, 0) == id) {
                            modelo.setValueAt(rsSinAlquiler.getInt(2), i, 2);
                            rsSinAlquiler.next();
                        }
                    }
                }
                catch (SQLException e) {}
            }
            
            jTable.setModel(modelo);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al intentar cargar las estadisticas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ejecuta las consultas con los filtros necesarios (mes, año o ambos)
    private void btnAplicarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        try {
            String mes = txtMes.getText();
            String anyo = txtAnyo.getText();

            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            ResultSet rsContratosIniciados = null, rsContratosFinalizados = null, rsViviendas = null;

            if (mes.isBlank() && !(anyo.isBlank())) {
                rsContratosIniciados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE YEAR(fecha_inicio) = " + anyo);
                rsContratosFinalizados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE YEAR(fecha_fin) = " + anyo + " AND estado = 3");
                rsViviendas = Consultas.consultarCustom(con, "SELECT DISTINCT COUNT(codigo_vivienda), ROUND(AVG(precio), 2) FROM contrata WHERE YEAR(fecha_inicio) <= " + anyo + " AND YEAR(fecha_fin) >= " + anyo + " AND estado = 2");
            }
            else if (!(mes.isBlank()) && anyo.isBlank()) {
                rsContratosIniciados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE MONTH(fecha_inicio) = " + mes);
                rsContratosFinalizados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE MONTH(fecha_fin) = " + mes + " AND estado = 3");
                rsViviendas = Consultas.consultarCustom(con, "SELECT DISTINCT COUNT(codigo_vivienda), ROUND(AVG(precio), 2) FROM contrata WHERE MONTH(fecha_inicio) <= " + mes + " AND (MONTH(fecha_fin) >= " + mes + " OR (MONTH(fecha_fin) <= " + mes + " AND YEAR(fecha_fin) > YEAR(fecha_inicio))) AND estado = 2");
            }
            else {
                rsContratosIniciados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE YEAR(fecha_inicio) = " + anyo + " AND MONTH(fecha_inicio) = " + mes);
                rsContratosFinalizados = Consultas.consultarCustom(con, "SELECT COUNT(*) FROM contrata WHERE YEAR(fecha_fin) = " + anyo + " AND MONTH(fecha_fin) = " + mes + " AND estado = 3");
                rsViviendas = Consultas.consultarCustom(con, "SELECT DISTINCT COUNT(codigo_vivienda), ROUND(AVG(precio), 2) FROM contrata WHERE (YEAR(fecha_inicio) <= " + anyo + " AND MONTH(fecha_inicio) <= " + mes + ") AND (YEAR(fecha_fin) >= " + anyo + " AND MONTH(fecha_fin) >= " + mes + " OR (MONTH(fecha_fin) <= " + mes + " AND YEAR(fecha_fin) > YEAR(fecha_inicio))) AND estado = 2");
            }

            rsContratosIniciados.next();
            rsContratosFinalizados.next();
            rsViviendas.next();

            txtContratosIniciados.setText(String.valueOf(rsContratosIniciados.getInt(1)));
            txtContratosFinalizados.setText(String.valueOf(rsContratosFinalizados.getInt(1)));
            txtViviendasAlquiler.setText(String.valueOf(rsViviendas.getInt(1)));
            txtPrecioMedio.setText(String.valueOf(rsViviendas.getDouble(2)));

        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al intentar cargar las estadisticas", "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }                        


    // Variables declaration - do not modify                     
    private javax.swing.JButton btnAplicar;
    private javax.swing.JButton btnAtras;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable;
    private javax.swing.JTextField txtAnyo;
    private javax.swing.JTextField txtContratosFinalizados;
    private javax.swing.JTextField txtContratosIniciados;
    private javax.swing.JTextField txtMes;
    private javax.swing.JTextField txtPrecioMedio;
    private javax.swing.JTextField txtViviendasAlquiler;
    // End of variables declaration                   
}

