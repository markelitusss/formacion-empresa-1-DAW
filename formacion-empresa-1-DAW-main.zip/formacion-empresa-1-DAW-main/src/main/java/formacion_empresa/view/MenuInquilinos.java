/********************************/
/*  Formación Empresa           */
/*  Clase menú inquilinos       */
/*  Markel Canales Ramos 1º DAW */
/********************************/

package formacion_empresa.view;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.nio.channels.ClosedByInterruptException;
import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import formacion_empresa.controller.Conexion;
import formacion_empresa.controller.Consultas;
import formacion_empresa.controller.CRUDinquilino;
import formacion_empresa.model.Inquilino;

/**
 *
 * @author Markel Canales Ramos
 */
public class MenuInquilinos extends javax.swing.JPanel {

    DefaultTableModel modelo;
    
    // deshabilita los botones
    public void deshabilitarBtns() {
        btnConsultar.setEnabled(false);
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnExportar.setEnabled(false);
    }
    
    // habilita los botones
    public void habilitarBtns() {
        btnConsultar.setEnabled(true);
        btnInsertar.setEnabled(true);
        btnModificar.setEnabled(true);
        btnEliminar.setEnabled(true);
        btnExportar.setEnabled(true);
    }

    public MenuInquilinos() {
        initComponents();
        modelo = (DefaultTableModel) TableInquilinos.getModel();
        setVisible(false);

        // cuando se cierre el formulario de inserción se deben habilitar los botones para evitar que se queden desactivados
        jFrameInsertar.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentHidden(ComponentEvent e) {
                habilitarBtns();
            }
        });

        // cuando se cierre el formulario de actualización se deben habilitar los botones para evitar que se queden desactivados
        jFrameModificar.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentHidden(ComponentEvent e) {
                habilitarBtns();
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jFrameInsertar = new javax.swing.JFrame();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnAceptar_ins = new javax.swing.JButton();
        txtDNI_ins = new javax.swing.JTextField();
        txtNombre_ins = new javax.swing.JTextField();
        txtEmail_ins = new javax.swing.JTextField();
        txtTelefono_ins = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jFrameModificar = new javax.swing.JFrame();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        btnAceptar_mod = new javax.swing.JButton();
        txtID_mod = new javax.swing.JTextField();
        txtDNI_mod = new javax.swing.JTextField();
        txtNombre_mod = new javax.swing.JTextField();
        txtEmail_mod = new javax.swing.JTextField();
        txtTelefono_mod = new javax.swing.JTextField();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        btnAtras = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableInquilinos = new javax.swing.JTable();
        btnConsultar = new javax.swing.JButton();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();

        jFrameInsertar.setTitle("Inserción");
        jFrameInsertar.setAlwaysOnTop(true);
        jFrameInsertar.setPreferredSize(new java.awt.Dimension(400, 400));

        jLabel2.setText("DNI:");

        jLabel3.setText("Nombre:");

        jLabel4.setText("E-mail:");

        jLabel5.setText("Telefono:");

        jLabel6.setText("Mascota:");

        btnAceptar_ins.setText("Aceptar");
        btnAceptar_ins.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptar_insActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setSelected(true);
        jRadioButton1.setText("Si");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("No");

        javax.swing.GroupLayout jFrameInsertarLayout = new javax.swing.GroupLayout(jFrameInsertar.getContentPane());
        jFrameInsertar.getContentPane().setLayout(jFrameInsertarLayout);
        jFrameInsertarLayout.setHorizontalGroup(
            jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel2)
                .addGap(85, 85, 85)
                .addComponent(txtDNI_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel3)
                .addGap(61, 61, 61)
                .addComponent(txtNombre_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel4)
                .addGap(72, 72, 72)
                .addComponent(txtEmail_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel5)
                .addGap(58, 58, 58)
                .addComponent(txtTelefono_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel6)
                .addGap(59, 59, 59)
                .addComponent(jRadioButton1)
                .addGap(17, 17, 17)
                .addComponent(jRadioButton2))
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(btnAceptar_ins, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jFrameInsertarLayout.setVerticalGroup(
            jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameInsertarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtDNI_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txtNombre_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txtEmail_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(txtTelefono_ins, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jFrameInsertarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2))
                .addGap(49, 49, 49)
                .addComponent(btnAceptar_ins))
        );

        jFrameModificar.setTitle("Modificación");
        jFrameModificar.setAlwaysOnTop(true);
        jFrameModificar.setPreferredSize(new java.awt.Dimension(400, 400));

        jLabel7.setText("ID:");

        jLabel8.setText("DNI:");

        jLabel9.setText("Nombre:");

        jLabel10.setText("E-mail:");

        jLabel11.setText("Telefono:");

        jLabel12.setText("Mascota (Y/N):");

        btnAceptar_mod.setText("Aceptar");
        btnAceptar_mod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptar_modActionPerformed(evt);
            }
        });

        buttonGroup2.add(jRadioButton3);
        jRadioButton3.setSelected(true);
        jRadioButton3.setText("Si");

        buttonGroup2.add(jRadioButton4);
        jRadioButton4.setText("No");

        javax.swing.GroupLayout jFrameModificarLayout = new javax.swing.GroupLayout(jFrameModificar.getContentPane());
        jFrameModificar.getContentPane().setLayout(jFrameModificarLayout);
        jFrameModificarLayout.setHorizontalGroup(
            jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrameModificarLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(94, 94, 94)
                        .addComponent(txtID_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jFrameModificarLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(85, 85, 85)
                        .addComponent(txtDNI_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jFrameModificarLayout.createSequentialGroup()
                        .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addGap(61, 61, 61)
                        .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmail_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombre_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jFrameModificarLayout.createSequentialGroup()
                        .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12))
                        .addGap(28, 28, 28)
                        .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButton3)
                            .addComponent(txtTelefono_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jFrameModificarLayout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jRadioButton4)
                            .addComponent(btnAceptar_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(143, 143, 143))
        );
        jFrameModificarLayout.setVerticalGroup(
            jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrameModificarLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(txtID_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(txtDNI_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(txtNombre_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtEmail_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(txtTelefono_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(jFrameModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jRadioButton3)
                        .addComponent(jRadioButton4)))
                .addGap(18, 18, 18)
                .addComponent(btnAceptar_mod)
                .addContainerGap())
        );

        setPreferredSize(new java.awt.Dimension(800, 600));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                MenuInquilinos.this.componentShown(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setText("INQUILINOS ENCONTRADOS");

        btnAtras.setText("Volver");
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });

        TableInquilinos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "DNI", "Nombre", "E-mail", "Telefono", "Mascota/s"
            }
        ) {
            @SuppressWarnings("rawtypes")
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true
            };

            @SuppressWarnings("rawtypes")
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TableInquilinos);

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnExportar.setText("Exportar");
        btnExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnAtras)
                .addGap(578, 578, 578)
                .addComponent(btnExportar))
            .addGroup(layout.createSequentialGroup()
                .addGap(270, 270, 270)
                .addComponent(jLabel1))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(btnConsultar)
                .addGap(111, 111, 111)
                .addComponent(btnInsertar)
                .addGap(119, 119, 119)
                .addComponent(btnModificar)
                .addGap(112, 112, 112)
                .addComponent(btnEliminar))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAtras)
                    .addComponent(btnExportar))
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnConsultar)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)))
        );
    }

    // oculta este panel y vuelve al menú principal
    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {
        setVisible(false);
        modelo.setRowCount(0);
    }

    // método que se ejecuta cada vez que se muestra este panel
    // se rellena la tabla utilizando la función consultarTodo() de la clase Consultas
    private void componentShown(java.awt.event.ComponentEvent evt) {
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            ResultSet rs = Consultas.consultarTodo(con, "inquilino");

            if (rs == null) {
                throw new SQLException();
            }
            else {
                int rowCount = 0;

                while (rs.next()) {
                    modelo.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
                    Object mascota;
                    if (rs.getBoolean(6)) {
                        mascota = "Si";
                    }
                    else {
                        mascota = "No";
                    }

                    modelo.setValueAt(mascota, rowCount, 5);
                    rowCount++;
                }
                
                TableInquilinos.setModel(modelo);
            }

            con.close();
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al obtener los datos de la tabla Inquilino", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ordena ejecutar la consulta y la muestra en la tabla
    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            String id = JOptionPane.showInputDialog(null, "Introduzca el ID del inquilino:", "Consultar", JOptionPane.PLAIN_MESSAGE);

            if (id == null) {
                throw new ClosedByInterruptException();
            }

            Inquilino i = CRUDinquilino.consultar(con, Integer.parseInt(id));

            if (i == null) {
                throw new SQLException();
            }
            else if (i.getId() == -2) {
                throw new NullPointerException();
            }
            else {
                modelo.setRowCount(0);
                modelo.addRow(new Object[]{i.getId(), i.getDNI(), i.getNombre(), i.getEmail(), i.getTelefono()});
                Object mascota;
                if (i.getMascota()) {
                    mascota = "Si";
                }
                else {
                    mascota = "No";
                }

                modelo.setValueAt(mascota, 0, 5);
            }

            con.close();
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El valor introducido debe ser un número entero", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al consultar la tabla Inquilino", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El ID indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ClosedByInterruptException e) {}
        
        habilitarBtns();
    }

    // muestra el formulario de inserción
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        jFrameInsertar.pack();
        jFrameInsertar.setLocationRelativeTo(null);
        jFrameInsertar.setVisible(true);
    }

    // muestra el formulario de actualización
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        jFrameModificar.pack();
        jFrameModificar.setLocationRelativeTo(null);
        jFrameModificar.setVisible(true);
    }

    // ejecuta el método de borrado de inquilino
    // antes de borrar pregunta al usuario si está seguro que quiere realizar esa acción
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {
        deshabilitarBtns();
        
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            String idStr = JOptionPane.showInputDialog(null, "Introduzca el ID del inquilino:", "Eliminar", JOptionPane.PLAIN_MESSAGE);
            if (idStr == null) {
                throw new ClosedByInterruptException();
            }

            int id = Integer.parseInt(idStr);
            int err;

            if (JOptionPane.showConfirmDialog(null, "¿Seguro que quiere eliminar el registro con ID " + id + "?", "Confirmación", JOptionPane.YES_NO_OPTION) == 0) {
                err = CRUDinquilino.eliminar(con, id);
                if (err == -1) {
                    throw new SQLException();
                }
                else if (err == -2) {
                    throw new NullPointerException();
                }
            }

            con.close();
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El valor introducido debe ser un número entero", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar de la tabla Inquilino. No se ha realizado ningún cambio", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El ID indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ClosedByInterruptException e) {}
        
        habilitarBtns();
        modelo.setRowCount(0);
        componentShown(null);
    }

    // recibe los datos del formulario y ordena ejecutar la inserción
    private void btnAceptar_insActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String DNI = txtDNI_ins.getText();
            String nombre = txtNombre_ins.getText();
            String email = txtEmail_ins.getText();
            String telefono = txtTelefono_ins.getText();
            boolean mascota;
            if (jRadioButton1.isSelected()) {
                mascota = true;
            }
            else {
                mascota = false;
            }

            if (DNI.isBlank() || nombre.isBlank()) {
                throw new NullPointerException();    
            }
            
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            int id_ins = CRUDinquilino.insertar(con, new Inquilino(0, DNI, nombre, email, telefono, mascota));

            if (id_ins == -1) {
                throw new SQLException();
            }

            JOptionPane.showMessageDialog(null, "Inquilino insertado con ID: " + id_ins, "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            con.close();
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Debes introducir al menos DNI y nombre", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar insertar en la tabla Inquilino", "Error", JOptionPane.ERROR_MESSAGE);
        }

        jFrameInsertar.setVisible(false);
        habilitarBtns();

        modelo.setRowCount(0);
        componentShown(null);
    }

    // recibe los datos del formulario y ordena ejecutar la actualización
    private void btnAceptar_modActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int id = Integer.parseInt(txtID_mod.getText());
            String DNI = txtDNI_mod.getText();
            String nombre = txtNombre_mod.getText();
            String email = txtEmail_mod.getText();
            String telefono = txtTelefono_mod.getText();
            boolean mascota;
            if (jRadioButton1.isSelected()) {
                mascota = true;
            }
            else {
                mascota = false;
            }

            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            Inquilino oldI = CRUDinquilino.consultar(con, id);
            Inquilino newI = new Inquilino(id, DNI, nombre, email, telefono, mascota);

            // si el usuario deja campos en blanco no se actualizarán
            if (newI.getDNI().isBlank()) {
                newI.setDNI(oldI.getDNI());
            }
            if (newI.getNombre().isBlank()) {
                newI.setNombre(oldI.getNombre());
            }
            if (newI.getEmail().isBlank()) {
                newI.setEmail(oldI.getEmail());
            }
            if (newI.getTelefono().isBlank()) {
                newI.setTelefono(oldI.getTelefono());
            }

            int err = CRUDinquilino.actualizar(con, newI);

            if (err == -1) throw new SQLException();
            else if (err == -2) throw new NullPointerException();
            else JOptionPane.showMessageDialog(null, "Los datos han sido modificados correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

            con.close();
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID introducido debe ser un número entero", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al actualizar los datos de la tabla Inquilino", "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El ID indicado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        }

        jFrameModificar.setVisible(false);
        habilitarBtns();

        modelo.setRowCount(0);
        componentShown(null);
    }

    // ordena ejecutar la exportación de la tabla
    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Connection con = Conexion.getConexion(Conexion.getUrl(), Conexion.getUser(), Conexion.getPassword());
            int err = Consultas.exportar(con, "inquilino");

            if (err == 0) {
                JOptionPane.showMessageDialog(null, "Tabla exportada a CSV correctamente");
            }
            else {
                throw new Exception();
            }

            con.close();
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar exportar la tabla Inquilino", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    // Variables declaration - do not modify
    private javax.swing.JTable TableInquilinos;
    private javax.swing.JButton btnAceptar_ins;
    private javax.swing.JButton btnAceptar_mod;
    private javax.swing.JButton btnAtras;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JFrame jFrameInsertar;
    private javax.swing.JFrame jFrameModificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtDNI_ins;
    private javax.swing.JTextField txtDNI_mod;
    private javax.swing.JTextField txtEmail_ins;
    private javax.swing.JTextField txtEmail_mod;
    private javax.swing.JTextField txtID_mod;
    private javax.swing.JTextField txtNombre_ins;
    private javax.swing.JTextField txtNombre_mod;
    private javax.swing.JTextField txtTelefono_ins;
    private javax.swing.JTextField txtTelefono_mod;
    // End of variables declaration
}
